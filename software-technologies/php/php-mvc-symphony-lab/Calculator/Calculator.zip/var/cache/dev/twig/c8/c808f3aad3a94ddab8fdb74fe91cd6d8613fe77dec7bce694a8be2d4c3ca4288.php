<?php

/* @WebProfiler/Collector/router.html.twig */
class __TwigTemplate_0b5fa52931450738cdfabed37c625b94d2c8421d8fa332bcc961ba1fe909c0a9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1a24e4c42ba2c1cb087b110e53bbfaa7f561896e165eb2ff38ebf603bceb88e7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1a24e4c42ba2c1cb087b110e53bbfaa7f561896e165eb2ff38ebf603bceb88e7->enter($__internal_1a24e4c42ba2c1cb087b110e53bbfaa7f561896e165eb2ff38ebf603bceb88e7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_1a24e4c42ba2c1cb087b110e53bbfaa7f561896e165eb2ff38ebf603bceb88e7->leave($__internal_1a24e4c42ba2c1cb087b110e53bbfaa7f561896e165eb2ff38ebf603bceb88e7_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_4de5422760bfea37294348e01d8bc39a154e3308ad1081fbcef0e94ced9da604 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4de5422760bfea37294348e01d8bc39a154e3308ad1081fbcef0e94ced9da604->enter($__internal_4de5422760bfea37294348e01d8bc39a154e3308ad1081fbcef0e94ced9da604_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_4de5422760bfea37294348e01d8bc39a154e3308ad1081fbcef0e94ced9da604->leave($__internal_4de5422760bfea37294348e01d8bc39a154e3308ad1081fbcef0e94ced9da604_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_0b56bd172798751f9e18c7aee9b24b9b48d2b34acacfe453cf0516cf4b54b26b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0b56bd172798751f9e18c7aee9b24b9b48d2b34acacfe453cf0516cf4b54b26b->enter($__internal_0b56bd172798751f9e18c7aee9b24b9b48d2b34acacfe453cf0516cf4b54b26b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_0b56bd172798751f9e18c7aee9b24b9b48d2b34acacfe453cf0516cf4b54b26b->leave($__internal_0b56bd172798751f9e18c7aee9b24b9b48d2b34acacfe453cf0516cf4b54b26b_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_abd8b405a704508e5c067103d527282866435e647878d302dc017731dc9bc64f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_abd8b405a704508e5c067103d527282866435e647878d302dc017731dc9bc64f->enter($__internal_abd8b405a704508e5c067103d527282866435e647878d302dc017731dc9bc64f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\HttpKernelExtension')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_router", array("token" => (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_abd8b405a704508e5c067103d527282866435e647878d302dc017731dc9bc64f->leave($__internal_abd8b405a704508e5c067103d527282866435e647878d302dc017731dc9bc64f_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  73 => 13,  67 => 12,  56 => 7,  53 => 6,  47 => 5,  36 => 3,  11 => 1,);
    }

    public function getSource()
    {
        return "{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}{% endblock %}

{% block menu %}
<span class=\"label\">
    <span class=\"icon\">{{ include('@WebProfiler/Icon/router.svg') }}</span>
    <strong>Routing</strong>
</span>
{% endblock %}

{% block panel %}
    {{ render(path('_profiler_router', { token: token })) }}
{% endblock %}
";
    }
}
