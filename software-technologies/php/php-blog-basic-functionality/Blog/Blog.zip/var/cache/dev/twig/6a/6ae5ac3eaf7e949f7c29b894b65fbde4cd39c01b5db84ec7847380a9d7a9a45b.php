<?php

/* @WebProfiler/Collector/router.html.twig */
class __TwigTemplate_14d3d64b2141fd6c846d56a481c1f3e8e270bd15686614de329942a9e9bb1b2b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c1333b5ddd3df03695608168f545282eff0052a2e4cdd164a680ebaf4b99b456 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c1333b5ddd3df03695608168f545282eff0052a2e4cdd164a680ebaf4b99b456->enter($__internal_c1333b5ddd3df03695608168f545282eff0052a2e4cdd164a680ebaf4b99b456_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_c1333b5ddd3df03695608168f545282eff0052a2e4cdd164a680ebaf4b99b456->leave($__internal_c1333b5ddd3df03695608168f545282eff0052a2e4cdd164a680ebaf4b99b456_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_a36eef98dc7902cb37e8a5bffd879c3a219f6989d790cdc98368c0c1ccb45867 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a36eef98dc7902cb37e8a5bffd879c3a219f6989d790cdc98368c0c1ccb45867->enter($__internal_a36eef98dc7902cb37e8a5bffd879c3a219f6989d790cdc98368c0c1ccb45867_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_a36eef98dc7902cb37e8a5bffd879c3a219f6989d790cdc98368c0c1ccb45867->leave($__internal_a36eef98dc7902cb37e8a5bffd879c3a219f6989d790cdc98368c0c1ccb45867_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_51db78e02ee6c46d930fb623f8d16315dde05e4ee56262fb00ec870f4f62c470 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_51db78e02ee6c46d930fb623f8d16315dde05e4ee56262fb00ec870f4f62c470->enter($__internal_51db78e02ee6c46d930fb623f8d16315dde05e4ee56262fb00ec870f4f62c470_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_51db78e02ee6c46d930fb623f8d16315dde05e4ee56262fb00ec870f4f62c470->leave($__internal_51db78e02ee6c46d930fb623f8d16315dde05e4ee56262fb00ec870f4f62c470_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_5a912303871cf6a36a141703f9100cbfc32d0cff784b47bfa4d895ad886f4e3f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5a912303871cf6a36a141703f9100cbfc32d0cff784b47bfa4d895ad886f4e3f->enter($__internal_5a912303871cf6a36a141703f9100cbfc32d0cff784b47bfa4d895ad886f4e3f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\HttpKernelExtension')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_router", array("token" => (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_5a912303871cf6a36a141703f9100cbfc32d0cff784b47bfa4d895ad886f4e3f->leave($__internal_5a912303871cf6a36a141703f9100cbfc32d0cff784b47bfa4d895ad886f4e3f_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  73 => 13,  67 => 12,  56 => 7,  53 => 6,  47 => 5,  36 => 3,  11 => 1,);
    }

    public function getSource()
    {
        return "{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}{% endblock %}

{% block menu %}
<span class=\"label\">
    <span class=\"icon\">{{ include('@WebProfiler/Icon/router.svg') }}</span>
    <strong>Routing</strong>
</span>
{% endblock %}

{% block panel %}
    {{ render(path('_profiler_router', { token: token })) }}
{% endblock %}
";
    }
}
