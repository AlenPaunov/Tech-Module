<?php

/* user/profile.html.twig */
class __TwigTemplate_078c422775a12219815c8a12bfec025b134bcdbdd669fbb330efc32c41a6896b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "user/profile.html.twig", 1);
        $this->blocks = array(
            'body_id' => array($this, 'block_body_id'),
            'main' => array($this, 'block_main'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1361895bcdbe522049f368994010f3485770eb41dfd6ed66f6a7d6bd2bb892be = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1361895bcdbe522049f368994010f3485770eb41dfd6ed66f6a7d6bd2bb892be->enter($__internal_1361895bcdbe522049f368994010f3485770eb41dfd6ed66f6a7d6bd2bb892be_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "user/profile.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_1361895bcdbe522049f368994010f3485770eb41dfd6ed66f6a7d6bd2bb892be->leave($__internal_1361895bcdbe522049f368994010f3485770eb41dfd6ed66f6a7d6bd2bb892be_prof);

    }

    // line 3
    public function block_body_id($context, array $blocks = array())
    {
        $__internal_e323c92aa4db64ba822de6a16923803920f04d6079419539599f5ac4c98517e9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e323c92aa4db64ba822de6a16923803920f04d6079419539599f5ac4c98517e9->enter($__internal_e323c92aa4db64ba822de6a16923803920f04d6079419539599f5ac4c98517e9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        echo "profile";
        
        $__internal_e323c92aa4db64ba822de6a16923803920f04d6079419539599f5ac4c98517e9->leave($__internal_e323c92aa4db64ba822de6a16923803920f04d6079419539599f5ac4c98517e9_prof);

    }

    // line 5
    public function block_main($context, array $blocks = array())
    {
        $__internal_0fb5f6f5d20b0ea498a22db823e5177ca6597783fa9c850917e2653e9d7a4b75 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0fb5f6f5d20b0ea498a22db823e5177ca6597783fa9c850917e2653e9d7a4b75->enter($__internal_0fb5f6f5d20b0ea498a22db823e5177ca6597783fa9c850917e2653e9d7a4b75_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 6
        echo "    <div>
        ";
        // line 7
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "email", array()), "html", null, true);
        echo "
        <br>
        ";
        // line 9
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "fullName", array()), "html", null, true);
        echo "
    </div>
";
        
        $__internal_0fb5f6f5d20b0ea498a22db823e5177ca6597783fa9c850917e2653e9d7a4b75->leave($__internal_0fb5f6f5d20b0ea498a22db823e5177ca6597783fa9c850917e2653e9d7a4b75_prof);

    }

    public function getTemplateName()
    {
        return "user/profile.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  61 => 9,  56 => 7,  53 => 6,  47 => 5,  35 => 3,  11 => 1,);
    }

    public function getSource()
    {
        return "{% extends 'base.html.twig' %}

{% block body_id 'profile' %}

{% block main %}
    <div>
        {{ user.email }}
        <br>
        {{ user.fullName }}
    </div>
{% endblock %}
";
    }
}
