<?php

/* @Twig/Exception/exception_full.html.twig */
class __TwigTemplate_5966350cd43e89931088befbcacddaed354a50738d06d3a0da9bb4b140a46238 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@Twig/layout.html.twig", "@Twig/Exception/exception_full.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@Twig/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_16b23ff1954379c41b821b682b63de87113e6e7070a7c24431b12a9dc1a640a6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_16b23ff1954379c41b821b682b63de87113e6e7070a7c24431b12a9dc1a640a6->enter($__internal_16b23ff1954379c41b821b682b63de87113e6e7070a7c24431b12a9dc1a640a6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception_full.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_16b23ff1954379c41b821b682b63de87113e6e7070a7c24431b12a9dc1a640a6->leave($__internal_16b23ff1954379c41b821b682b63de87113e6e7070a7c24431b12a9dc1a640a6_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_d6c7ef0d5d0437c8ef33fc2bcf9171f8dad9b368f5c1e8e17bc2d55f59ea5e15 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d6c7ef0d5d0437c8ef33fc2bcf9171f8dad9b368f5c1e8e17bc2d55f59ea5e15->enter($__internal_d6c7ef0d5d0437c8ef33fc2bcf9171f8dad9b368f5c1e8e17bc2d55f59ea5e15_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    <link href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\HttpFoundationExtension')->generateAbsoluteUrl($this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/framework/css/exception.css")), "html", null, true);
        echo "\" rel=\"stylesheet\" type=\"text/css\" media=\"all\" />
";
        
        $__internal_d6c7ef0d5d0437c8ef33fc2bcf9171f8dad9b368f5c1e8e17bc2d55f59ea5e15->leave($__internal_d6c7ef0d5d0437c8ef33fc2bcf9171f8dad9b368f5c1e8e17bc2d55f59ea5e15_prof);

    }

    // line 7
    public function block_title($context, array $blocks = array())
    {
        $__internal_98e63aa093a19baa3efcf9d41d6cf7a1848d1c260f2e34062ade24868b07e474 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_98e63aa093a19baa3efcf9d41d6cf7a1848d1c260f2e34062ade24868b07e474->enter($__internal_98e63aa093a19baa3efcf9d41d6cf7a1848d1c260f2e34062ade24868b07e474_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 8
        echo "    ";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")), "message", array()), "html", null, true);
        echo " (";
        echo twig_escape_filter($this->env, (isset($context["status_code"]) ? $context["status_code"] : $this->getContext($context, "status_code")), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, (isset($context["status_text"]) ? $context["status_text"] : $this->getContext($context, "status_text")), "html", null, true);
        echo ")
";
        
        $__internal_98e63aa093a19baa3efcf9d41d6cf7a1848d1c260f2e34062ade24868b07e474->leave($__internal_98e63aa093a19baa3efcf9d41d6cf7a1848d1c260f2e34062ade24868b07e474_prof);

    }

    // line 11
    public function block_body($context, array $blocks = array())
    {
        $__internal_06f70092fd807151343e6f2b1aff8946f56b669d453ae4bc2080ee610616e190 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_06f70092fd807151343e6f2b1aff8946f56b669d453ae4bc2080ee610616e190->enter($__internal_06f70092fd807151343e6f2b1aff8946f56b669d453ae4bc2080ee610616e190_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 12
        echo "    ";
        $this->loadTemplate("@Twig/Exception/exception.html.twig", "@Twig/Exception/exception_full.html.twig", 12)->display($context);
        
        $__internal_06f70092fd807151343e6f2b1aff8946f56b669d453ae4bc2080ee610616e190->leave($__internal_06f70092fd807151343e6f2b1aff8946f56b669d453ae4bc2080ee610616e190_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/exception_full.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  78 => 12,  72 => 11,  58 => 8,  52 => 7,  42 => 4,  36 => 3,  11 => 1,);
    }

    public function getSource()
    {
        return "{% extends '@Twig/layout.html.twig' %}

{% block head %}
    <link href=\"{{ absolute_url(asset('bundles/framework/css/exception.css')) }}\" rel=\"stylesheet\" type=\"text/css\" media=\"all\" />
{% endblock %}

{% block title %}
    {{ exception.message }} ({{ status_code }} {{ status_text }})
{% endblock %}

{% block body %}
    {% include '@Twig/Exception/exception.html.twig' %}
{% endblock %}
";
    }
}
