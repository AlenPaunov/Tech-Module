<?php

namespace SoftUniBlogBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class SoftUniBlogBundle extends Bundle
{
}
